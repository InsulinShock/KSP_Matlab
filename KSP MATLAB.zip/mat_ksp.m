%MATLAB-KERBAL SPACE PROGRAM EXAMPLE SCRIPT
%This script demonstrates an example "OPEN-LOOP" procedure for the launch
%of a moderate rocket into Kerbin orbit. All basic functionality is present
%for improved "CLOSED-LOOP" flight control, but is not currently.
%
%



%% ==================== CONNECT TO KSP ====================================
%This section connects to KSP through an internal COM port

%*** Register The COM port ***
t=tcpip('127.0.0.1', 25001, 'NetworkRole', 'server');

%*** Attempt to Open The Com Port ***
%Program will hang here until ship is brought to launch-pad in KSP
fopen(t);


%% ====================== PREPARE FOR LAUNCH ==============================

% *** Turn on Auto-Pilot ***
%Auto-pilot engages the Fly-by-Wire in KSP
twrite(t, uint8(32), 'uint8');
twrite(t, uint8(1), 'uint8');
while t.bytesAvailable < 1    
end
retcode = tread(t, 1, 'uint8');     %Return code from kerbal
%retcode should eventually be used for error checking of communication
%good retcode == 42 :)
pause(1);                   %delay


% *** Power Up Thrust ***
%Bring Thrust to 95% of maximum
twrite(t, uint8(34), 'uint8');
twrite(t, single(0.95), 'single');
while t.bytesAvailable < 1    
end
retcode = tread(t, 1, 'uint8');
pause(1);


%IMPORTANT:
% TURN ON "SAS" IN KSP BY PRESSING "T"

t


%% ======================= LAUNCH AND MONITOR FLIGHT ======================

% *** Create Displays ***
T = [];             %Flight Time
[X,Y,Z] = sphere(10);
f1 = figure(1);
surf(6e2*X,6e2*Y,6e2*Z);    
xlabel('X-axis [km]');ylabel('Y-axis [km]');zlabel('Z-axis [km]');
title('Position');


f2 = figure(2);
xlabel('Mission Time [sec]');
ylabel('q');
legend('w','x','y','z');
title('Quaternion');



% *** Trigger Flight ***
twrite(t, uint8(35), 'uint8');
while t.bytesAvailable < 1    
end
retcode = tread(t, 1, 'uint8');
pause(1);





% *** Record Flight ***
for i = 1:2000
    
    %----- Get Current Flight Time -----
    twrite(t, uint8(21), 'uint8');
    while t.bytesAvailable < 9
    end
    a = tread(t, 1, 'uint8');
    T(i) = tread(t, 1, 'double');
    
    pause(0.01);
    
    
    %----- Retrieve Position -----
    twrite(t, uint8(16), 'uint8');
    while t.bytesAvailable < 25
    end
    a = tread(t, 1, 'uint8');
    pos(i,:) = tread(t, 3, 'double');
    
    %disp('Hello');
    pause(0.01);
    
    %----- Retrieve Euler Rotation -----
    twrite(t, uint8(18), 'uint8');
    while t.bytesAvailable < 13
    end
    a = tread(t, 1, 'uint8');
    q(i,:) = tread(t, 4, 'single');
    pause(0.01);
     
    
        
    %----- Trigger Guidance Actions -----
%     twrite(t, uint8(33), 'uint8');
%     twrite(t, single(k*deltaEulerAngle(1)), 'single');
%     twrite(t, single(k*deltaEulerAngle(1)), 'single');
%     twrite(t, single(k*deltaEulerAngle(1)), 'single');
%     while t.bytesAvailable < 1
%     end
%     retcode = tread(t, 1, 'uint8');
        
    %----- Update Displays of Launch -----
    %Position
    set(0,'CurrentFigure',f1);
    hold on;    
    plot3(pos(i,1)*1e-3,pos(i,2)*1e-3,pos(i,3)*1e-3,'.');
    hold off;
    
        
    %Quaternion
    set(0,'CurrentFigure',f2);
    hold on;
    plot(   T(i),q(i,1),'m.',...
            T(i),q(i,2),'b.',...
            T(i),q(i,3),'g.',...
            T(i),q(i,4),'r.');
    hold off;
    
    
    %----- Delay Until Next Iteration -----
    disp(['Mission Time: ',num2str(T(i)),' [sec]']);
    pause(0.2);


end

