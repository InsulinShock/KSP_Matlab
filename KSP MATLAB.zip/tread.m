function A = tread(fileID, sizeA, precision)


for i = 1:sizeA

    switch precision
        case 'double'    
            B = fread(fileID,8,'uint8');
            A(i) = typecast(uint8(B),'double');

        case 'single'  
            B = fread(fileID,4,'uint8'); 
            A(i) = typecast(uint8(B),'single');            
                
        case 'int8'
            A(i) = fread(fileID,1,'int8');
               
        case 'uint8'
            A(i) = fread(fileID,1,'uint8');
        
        otherwise
            error('Invalid type');

    end

end

end