function [] = twrite(fileID, A, precision)
%TCP/IP WRITE
%This fucntion writes values to the stream, reordering to match with the
%encoding used in C#
%

for i = 1:size(A,2)
    
    switch precision
        case 'double'
            B = num2hex(A(i));
            for j = 1:8
                sentData(j) = uint8(hex2dec(B((1:2)+2*(8-j))));    
            end    
            fwrite(fileID,sentData,'uint8');

        case 'single'        
            B = num2hex(A(i));
            for j = 1:4
                sentData(j) = uint8(hex2dec(B((1:2)+2*(4-j))));    
            end    
            fwrite(fileID,sentData,'uint8');
                
        case 'int8'
            fwrite(fileID,A(i),'int8');        
        
        case 'uint8'
            fwrite(fileID,A(i),'uint8');  
        
        otherwise
            error('Invalid type');

    end
end

end